import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'newnaveader';
  dataarr: any[];
  constructor() { }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit() {
    this.dataarr = [{'id': '1', 'lock': true, 'title': 'aa', 'numone': '123', 'content': 'aa', 'numtwo': '3213'},
     {'id': '2' , 'lock': false, 'title': 'bb', 'numone': '444', 'content': 'bb', 'numtwo': '44332'} ,
     {'id': '3', 'lock': false, 'title': 'cc', 'numone': '123', 'content': 'cc', 'numtwo': '3213'},
     {'id': '4', 'lock': true, 'title': 'dd', 'numone': '56345', 'content': 'dd', 'numtwo': '343454'}];
     debugger;
  }
}
